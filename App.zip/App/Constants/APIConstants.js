const API_CONST = {

    N_USER_SIGNUP 						: 'N_USER_SIGNUP',

}
export default API_CONST
