
// import logo from '../Assets/logo.png';
// import logo_small from '../Assets/logo_small.png';
// import banner from '../Assets/banner.png'
// import sliderone from '../Assets/slide1.png'
// import slidertwo from '../Assets/slide2.png'
// import sliderthree from '../Assets/slide3.png'

// import use_user_icon from '../Assets/use-user.png';
// import default_user from '../Assets/default_user.png';


// import user_active_bottom_tab from '../Assets/user_active.png';
// import user_default_bottom_tab from '../Assets/user_default.png';
// import services_icon from '../Assets/services_icon.png';

// const IMAGEPATH = {
 
//     LOGO: logo,
//     LOGO_SMALL:logo_small,
//     //USER_DEFAULT:user_default_img,
//     USER_DEFAULT: default_user,
//     USE_USER_ICON: use_user_icon,
//     SLIDE_ONE:sliderone,
//     SLIDE_TWO:slidertwo,
//     SLIDE_THREE:sliderthree,

//     USER_ACTIVE_BOTTOM_TAB: user_active_bottom_tab,
//     USER_DEFAULT_BOTTOM_TAB: user_default_bottom_tab,

//     SERVICES_ICON:services_icon,

//     DASHBOARD_BANNER:banner

// }
// export default IMAGEPATH;
