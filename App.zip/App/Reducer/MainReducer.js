import { combineReducers } from 'redux';
import ContactReducer from '../Components/ContactComponent/ContactReducer';

export default combineReducers({

	contactReducer: ContactReducer,
	

});